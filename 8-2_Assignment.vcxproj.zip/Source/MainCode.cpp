///////////////////////////////////////////////////////////////////////////////
// 8-2_Assignment.cpp
// Collision-Based 2D Animation - Enhanced Breakout Style
// CS-330 Computational Graphics and Visualization
// Based on provided starter code
///////////////////////////////////////////////////////////////////////////////

#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <cmath>

using namespace std;

const float DEG2RAD = 3.14159f / 180.0f;

// ============================================================================
// ENUMS
// ============================================================================
enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE, MULTI_HIT };
enum ONOFF { ON, OFF };
enum DIRECTION {
    UP = 1, RIGHT = 2, DOWN = 3, LEFT = 4,
    UP_RIGHT = 5, UP_LEFT = 6, DOWN_RIGHT = 7, DOWN_LEFT = 8
};

// ============================================================================
// BRICK CLASS
// ============================================================================
class Brick
{
public:
    float red, green, blue;
    float x, y, width;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int health;           // For multi-hit bricks
    float originalRed, originalGreen, originalBlue; // For color changes

    // Constructor
    Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb, int h = 1)
    {
        brick_type = bt;
        x = xx;
        y = yy;
        width = ww;
        red = rr;
        green = gg;
        blue = bb;
        originalRed = rr;
        originalGreen = gg;
        originalBlue = bb;
        onoff = ON;
        health = h;
    };

    // Draw the brick
    void drawBrick()
    {
        if (onoff == ON)
        {
            double halfside = width / 2;

            // Darken brick based on remaining health
            float healthFactor = 1.0f;
            if (brick_type == MULTI_HIT) {
                healthFactor = (float)health / 3.0f; // Max health is 3
            }

            glColor3d(red * healthFactor, green * healthFactor, blue * healthFactor);
            glBegin(GL_POLYGON);

            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);

            glEnd();

            // Draw border for visual clarity
            glColor3d(0.8f, 0.8f, 0.8f);
            glBegin(GL_LINE_LOOP);
            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);
            glEnd();
        }
    }

    // Called when brick is hit
    void TakeHit()
    {
        if (brick_type == DESTRUCTABLE) {
            onoff = OFF;
        }
        else if (brick_type == MULTI_HIT) {
            health--;

            // Change color based on health
            if (health == 2) {
                // Orange - damaged
                red = 1.0f;
                green = 0.6f;
                blue = 0.0f;
            }
            else if (health == 1) {
                // Light blue - heavily damaged
                red = 0.0f;
                green = 0.6f;
                blue = 1.0f;
            }

            if (health <= 0) {
                onoff = OFF;
            }
        }
        // REFLECTIVE bricks don't get destroyed
    }
};

// ============================================================================
// CIRCLE CLASS
// ============================================================================
class Circle
{
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float speed;
    int direction;
    bool active;
    int hitCount;           // Track how many bricks this ball has hit
    int spawnCount;         // For tracking multi-ball spawning

    // Constructor
    Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
    {
        x = xx;
        y = yy;
        radius = rr;
        red = r;
        green = g;
        blue = b;
        radius = rad;
        direction = dir;
        speed = 0.03f + (rand() % 50) / 10000.0f; // Random speed variation
        active = true;
        hitCount = 0;
        spawnCount = 0;
    }

    // Check collision with a brick
    void CheckCollision(Brick* brk)
    {
        if (!active || brk->onoff == OFF) return;

        // Simple bounding box collision
        float halfWidth = brk->width / 2;
        float left = brk->x - halfWidth;
        float right = brk->x + halfWidth;
        float top = brk->y + halfWidth;
        float bottom = brk->y - halfWidth;

        // Check if circle is inside brick bounds
        bool collided = (x > left && x < right) && (y > bottom && y < top);

        if (collided) {
            if (brk->brick_type == REFLECTIVE) {
                // Bounce off reflective bricks
                direction = GetRandomDirection();

                // Slightly randomize speed for engagement
                speed *= (0.95f + (rand() % 100) / 5000.0f);
                if (speed > 0.08f) speed = 0.08f;
                if (speed < 0.02f) speed = 0.02f;

                // Push ball out to prevent sticking
                x += (rand() % 10 - 5) / 1000.0f;
                y += (rand() % 10 - 5) / 1000.0f;
            }
            else {
                // Hit destructible or multi-hit brick
                brk->TakeHit();
                hitCount++;

                // Bounce the ball
                direction = GetRandomDirection();

                // Speed changes after hitting bricks (physics)
                speed += 0.002f; // Slight speed increase
                if (speed > 0.08f) speed = 0.08f;

                // Push ball out
                x += (rand() % 10 - 5) / 1000.0f;
                y += (rand() % 10 - 5) / 1000.0f;

                // SPAWN MULTIPLE BALLS: When a ball hits enough bricks
                if (hitCount % 3 == 0 && hitCount > 0) {
                    // This will be handled in main loop
                }
            }
        }
    }

    // Check collision with another circle
    void CheckCircleCollision(Circle* other)
    {
        if (!active || !other->active) return;
        if (this == other) return;

        // Calculate distance between centers
        float dx = x - other->x;
        float dy = y - other->y;
        float distance = sqrt(dx * dx + dy * dy);
        float minDist = radius + other->radius;

        if (distance < minDist && distance > 0.001f) {
            // Elastic collision - swap directions
            int tempDir = direction;
            direction = other->direction;
            other->direction = tempDir;

            // Push balls apart
            float overlap = (minDist - distance) / 2.0f;
            float nx = dx / distance;
            float ny = dy / distance;
            x += nx * overlap;
            y += ny * overlap;
            other->x -= nx * overlap;
            other->y -= ny * overlap;

            // Random speed changes
            speed *= (0.98f + (rand() % 40) / 10000.0f);
            other->speed *= (0.98f + (rand() % 40) / 10000.0f);

            // Balls change color on collision
            float r1 = red, g1 = green, b1 = blue;
            red = other->red;
            green = other->green;
            blue = other->blue;
            other->red = r1;
            other->green = g1;
            other->blue = b1;
        }
    }

    int GetRandomDirection()
    {
        return (rand() % 8) + 1;
    }

    void MoveOneStep()
    {
        if (!active) return;

        // Up movements
        if (direction == UP || direction == UP_RIGHT || direction == UP_LEFT) {
            if (y > -1 + radius) {
                y -= speed;
            }
            else {
                // Bounce off top wall with physics (angle change)
                if (direction == UP) direction = DOWN;
                else if (direction == UP_RIGHT) direction = DOWN_RIGHT;
                else if (direction == UP_LEFT) direction = DOWN_LEFT;
                y = -1 + radius + 0.01f;

                // Wall friction - slow down slightly
                speed *= 0.99f;
            }
        }

        // Right movements
        if (direction == RIGHT || direction == UP_RIGHT || direction == DOWN_RIGHT) {
            if (x < 1 - radius) {
                x += speed;
            }
            else {
                if (direction == RIGHT) direction = LEFT;
                else if (direction == UP_RIGHT) direction = UP_LEFT;
                else if (direction == DOWN_RIGHT) direction = DOWN_LEFT;
                x = 1 - radius - 0.01f;
                speed *= 0.99f;
            }
        }

        // Down movements
        if (direction == DOWN || direction == DOWN_RIGHT || direction == DOWN_LEFT) {
            if (y < 1 - radius) {
                y += speed;
            }
            else {
                if (direction == DOWN) direction = UP;
                else if (direction == DOWN_RIGHT) direction = UP_RIGHT;
                else if (direction == DOWN_LEFT) direction = UP_LEFT;
                y = 1 - radius - 0.01f;
                speed *= 0.99f;
            }
        }

        // Left movements
        if (direction == LEFT || direction == UP_LEFT || direction == DOWN_LEFT) {
            if (x > -1 + radius) {
                x -= speed;
            }
            else {
                if (direction == LEFT) direction = RIGHT;
                else if (direction == UP_LEFT) direction = UP_RIGHT;
                else if (direction == DOWN_LEFT) direction = DOWN_RIGHT;
                x = -1 + radius + 0.01f;
                speed *= 0.99f;
            }
        }

        // Prevent balls from getting stuck with very low speed
        if (speed < 0.005f) {
            speed = 0.01f;
        }
    }

    void DrawCircle()
    {
        if (!active) return;

        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();

        // Draw a highlight for visual polish
        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 30; i++) {
            float degInRad = i * DEG2RAD;
            float hx = cos(degInRad) * radius * 0.3f + x + radius * 0.3f;
            float hy = sin(degInRad) * radius * 0.3f + y + radius * 0.3f;
            glVertex2f(hx, hy);
        }
        glEnd();
    }
};

// ============================================================================
// GLOBAL VARIABLES
// ============================================================================
vector<Circle> world;
vector<Brick> bricks;
int score = 0;
int lives = 3;
bool gameOver = false;
bool gameWon = false;
int totalBricks = 0;

// ============================================================================
// FUNCTION DECLARATIONS
// ============================================================================
void processInput(GLFWwindow* window);
void SpawnMultipleBalls(Circle& ball);
void SetupBricks();
void CheckAllCollisions();
void CheckWinCondition();
void DrawUI();

// ============================================================================
// MAIN FUNCTION
// ============================================================================
int main(void) {
    srand(static_cast<unsigned>(time(NULL)));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(640, 640, "8-2 Assignment: Breakout Enhanced", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // Setup the bricks
    SetupBricks();

    // Initial ball
    Circle initialBall(0, 0, 0.05f, UP_RIGHT, 0.05f, 1.0f, 1.0f, 1.0f);
    world.push_back(initialBall);

    while (!glfwWindowShouldClose(window)) {
        // Setup View
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        // Check all collisions
        CheckAllCollisions();

        // Movement and drawing
        for (int i = 0; i < world.size(); i++) {
            if (world[i].active) {
                world[i].MoveOneStep();
                world[i].DrawCircle();
            }
        }

        // Draw bricks
        for (auto& brick : bricks) {
            brick.drawBrick();
        }

        // Draw UI
        DrawUI();

        // Check win condition
        CheckWinCondition();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

// ============================================================================
// BRICK SETUP FUNCTION
// ============================================================================
void SetupBricks() {
    // Create a visually interesting layout with different brick types

    // REFLECTIVE bricks (bounce balls)
    bricks.push_back(Brick(REFLECTIVE, 0.0f, 0.7f, 0.15f, 1.0f, 1.0f, 0.0f)); // Yellow
    bricks.push_back(Brick(REFLECTIVE, -0.6f, 0.8f, 0.12f, 1.0f, 0.5f, 0.0f)); // Orange
    bricks.push_back(Brick(REFLECTIVE, 0.6f, 0.8f, 0.12f, 1.0f, 0.5f, 0.0f)); // Orange

    // MULTI_HIT bricks (need 3 hits)
    bricks.push_back(Brick(MULTI_HIT, -0.4f, 0.4f, 0.15f, 1.0f, 0.2f, 0.2f, 3)); // Red - 3 hits
    bricks.push_back(Brick(MULTI_HIT, 0.4f, 0.4f, 0.15f, 1.0f, 0.2f, 0.2f, 3)); // Red - 3 hits
    bricks.push_back(Brick(MULTI_HIT, -0.2f, 0.5f, 0.12f, 1.0f, 0.5f, 0.0f, 2)); // Orange - 2 hits
    bricks.push_back(Brick(MULTI_HIT, 0.2f, 0.5f, 0.12f, 1.0f, 0.5f, 0.0f, 2)); // Orange - 2 hits

    // DESTRUCTABLE bricks (1 hit)
    bricks.push_back(Brick(DESTRUCTABLE, -0.7f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f)); // Green
    bricks.push_back(Brick(DESTRUCTABLE, -0.5f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f));
    bricks.push_back(Brick(DESTRUCTABLE, -0.3f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.3f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.5f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.7f, 0.1f, 0.1f, 0.2f, 0.8f, 0.2f));

    bricks.push_back(Brick(DESTRUCTABLE, -0.6f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f)); // Cyan
    bricks.push_back(Brick(DESTRUCTABLE, -0.4f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f));
    bricks.push_back(Brick(DESTRUCTABLE, -0.2f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.2f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.4f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f));
    bricks.push_back(Brick(DESTRUCTABLE, 0.6f, -0.1f, 0.1f, 0.0f, 0.8f, 0.8f));

    bricks.push_back(Brick(DESTRUCTABLE, -0.3f, -0.3f, 0.12f, 0.8f, 0.2f, 0.8f)); // Purple
    bricks.push_back(Brick(DESTRUCTABLE, 0.3f, -0.3f, 0.12f, 0.8f, 0.2f, 0.8f));

    // Count total bricks
    totalBricks = 0;
    for (auto& b : bricks) {
        if (b.brick_type != REFLECTIVE) totalBricks++;
    }
}

// ============================================================================
// COLLISION FUNCTIONS
// ============================================================================
void CheckAllCollisions() {
    // Check ball-brick collisions
    for (int i = 0; i < world.size(); i++) {
        if (!world[i].active) continue;

        for (auto& brick : bricks) {
            if (brick.onoff == OFF) continue;
            world[i].CheckCollision(&brick);

            // Check if ball should spawn multiple balls
            if (world[i].hitCount > 0 && world[i].hitCount % 3 == 0 && world[i].spawnCount == 0) {
                SpawnMultipleBalls(world[i]);
                world[i].spawnCount++;
            }
        }
    }

    // Check ball-ball collisions
    for (int i = 0; i < world.size(); i++) {
        for (int j = i + 1; j < world.size(); j++) {
            if (world[i].active && world[j].active) {
                world[i].CheckCircleCollision(&world[j]);
            }
        }
    }
}

// ============================================================================
// SPAWN MULTIPLE BALLS FUNCTION
// ============================================================================
void SpawnMultipleBalls(Circle& ball) {
    // Spawn 2-3 new balls at the position of the hitting ball
    int numBalls = 2 + (rand() % 2);

    for (int i = 0; i < numBalls; i++) {
        float angle = ((rand() % 360) * 3.14159f) / 180.0f;
        float newX = ball.x + (cos(angle) * 0.1f);
        float newY = ball.y + (sin(angle) * 0.1f);

        // Random colors for new balls
        float r = 0.5f + (rand() % 100) / 200.0f;
        float g = 0.5f + (rand() % 100) / 200.0f;
        float b = 0.5f + (rand() % 100) / 200.0f;

        int dir = (rand() % 8) + 1;
        float speed = 0.02f + (rand() % 30) / 10000.0f;

        Circle newBall(newX, newY, 0.04f, dir, 0.04f, r, g, b);
        newBall.speed = speed;
        newBall.hitCount = ball.hitCount;
        world.push_back(newBall);
    }
}

// ============================================================================
// WIN CONDITION CHECK
// ============================================================================
void CheckWinCondition() {
    int activeBricks = 0;
    for (auto& brick : bricks) {
        if (brick.onoff == ON && brick.brick_type != REFLECTIVE) {
            activeBricks++;
        }
    }

    if (activeBricks == 0 && !gameOver) {
        gameWon = true;
    }
}

// ============================================================================
// DRAW UI
// ============================================================================
void DrawUI() {
    // Simple UI displayed as colored text areas
    // Score indicator
    glColor3f(1.0f, 1.0f, 1.0f);

    int activeBricks = 0;
    for (auto& brick : bricks) {
        if (brick.onoff == ON && brick.brick_type != REFLECTIVE) {
            activeBricks++;
        }
    }

    // Draw status indicators as small colored rectangles
    // Left side - Score
    glColor3f(0.0f, 0.5f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.98f, -0.98f);
    glVertex2f(-0.78f, -0.98f);
    glVertex2f(-0.78f, -0.88f);
    glVertex2f(-0.98f, -0.88f);
    glEnd();

    // Right side - Bricks remaining
    glColor3f(0.5f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.78f, -0.98f);
    glVertex2f(0.98f, -0.98f);
    glVertex2f(0.98f, -0.88f);
    glVertex2f(0.78f, -0.88f);
    glEnd();
}

// ============================================================================
// INPUT HANDLING
// ============================================================================
void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Space - create new ball
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        double r, g, b;
        r = (rand() % 100) / 100.0f;
        g = (rand() % 100) / 100.0f;
        b = (rand() % 100) / 100.0f;
        int dir = (rand() % 8) + 1;
        Circle B(0, 0, 0.05f, dir, 0.05f, (float)r, (float)g, (float)b);
        B.speed = 0.03f + (rand() % 30) / 10000.0f;
        world.push_back(B);
    }

    // 'R' key - Reset the game
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
        world.clear();
        bricks.clear();
        SetupBricks();
        Circle initialBall(0, 0, 0.05f, UP_RIGHT, 0.05f, 1.0f, 1.0f, 1.0f);
        world.push_back(initialBall);
        gameOver = false;
        gameWon = false;
    }
}